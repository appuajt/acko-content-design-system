/**
 * ACKO Content Validator - Figma Plugin
 * Main plugin code (runs in Figma sandbox)
 */

const API_ENDPOINT = 'http://localhost:5000/acko-validator';

interface ValidationResult {
  isValid: boolean;
  score: number;
  violations: Array<{
    id: string;
    rule: string;
    severity: 'error' | 'warning' | 'suggestion';
    message: string;
    context: string;
    suggestion?: string;
  }>;
}

interface TextNodeValidation {
  nodeId: string;
  nodeName: string;
  content: string;
  validation: ValidationResult;
}

// Show the plugin UI
figma.showUI(__html__, {
  width: 400,
  height: 600,
  themeColors: true,
});

// Listen for messages from UI
figma.ui.onmessage = async (msg) => {
  if (msg.type === 'scan-page') {
    await scanCurrentPage();
  } else if (msg.type === 'scan-selection') {
    await scanSelection();
  } else if (msg.type === 'apply-fix') {
    await applyFix(msg.nodeId, msg.fixedContent);
  } else if (msg.type === 'select-node') {
    selectNode(msg.nodeId);
  } else if (msg.type === 'close') {
    figma.closePlugin();
  }
};

/**
 * Scan all text nodes on the current page
 */
async function scanCurrentPage() {
  figma.ui.postMessage({ type: 'scan-start' });

  const textNodes = figma.currentPage.findAll(node => node.type === 'TEXT') as TextNode[];

  if (textNodes.length === 0) {
    figma.ui.postMessage({
      type: 'scan-complete',
      results: [],
      message: 'No text layers found on this page',
    });
    return;
  }

  figma.ui.postMessage({
    type: 'scan-progress',
    current: 0,
    total: textNodes.length,
  });

  const results: TextNodeValidation[] = [];

  for (let i = 0; i < textNodes.length; i++) {
    const node = textNodes[i];
    const content = node.characters;

    if (!content || content.trim().length === 0) {
      continue;
    }

    try {
      const validation = await validateContent(content);

      results.push({
        nodeId: node.id,
        nodeName: node.name,
        content,
        validation,
      });

      figma.ui.postMessage({
        type: 'scan-progress',
        current: i + 1,
        total: textNodes.length,
      });
    } catch (error) {
      console.error('Validation error for node:', node.name, error);
    }
  }

  // Sort by score (worst first)
  results.sort((a, b) => a.validation.score - b.validation.score);

  figma.ui.postMessage({
    type: 'scan-complete',
    results,
  });
}

/**
 * Scan selected text nodes only
 */
async function scanSelection() {
  const selection = figma.currentPage.selection;

  if (selection.length === 0) {
    figma.notify('Please select at least one text layer');
    return;
  }

  figma.ui.postMessage({ type: 'scan-start' });

  const textNodes = selection.filter(node => node.type === 'TEXT') as TextNode[];

  if (textNodes.length === 0) {
    figma.notify('No text layers in selection');
    figma.ui.postMessage({
      type: 'scan-complete',
      results: [],
      message: 'No text layers in selection',
    });
    return;
  }

  const results: TextNodeValidation[] = [];

  for (const node of textNodes) {
    const content = node.characters;

    if (!content || content.trim().length === 0) {
      continue;
    }

    try {
      const validation = await validateContent(content);

      results.push({
        nodeId: node.id,
        nodeName: node.name,
        content,
        validation,
      });
    } catch (error) {
      console.error('Validation error for node:', node.name, error);
    }
  }

  results.sort((a, b) => a.validation.score - b.validation.score);

  figma.ui.postMessage({
    type: 'scan-complete',
    results,
  });
}

/**
 * Validate content against ACKO guidelines
 */
async function validateContent(content: string): Promise<ValidationResult> {
  try {
    const response = await fetch(`${API_ENDPOINT}/validate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        content,
        contentType: 'ui-copy',
      }),
    });

    if (!response.ok) {
      throw new Error(`API error: ${response.status}`);
    }

    const data = await response.json();
    return data.data;
  } catch (error) {
    // Return a mock validation result if API is not available
    console.error('Validation API error:', error);
    return {
      isValid: true,
      score: 100,
      violations: [],
    };
  }
}

/**
 * Apply fix to a text node
 */
async function applyFix(nodeId: string, fixedContent: string) {
  const node = figma.getNodeById(nodeId);

  if (!node || node.type !== 'TEXT') {
    figma.notify('Text layer not found');
    return;
  }

  try {
    // Load the font before modifying text
    await figma.loadFontAsync(node.fontName as FontName);
    node.characters = fixedContent;
    figma.notify('✓ Fix applied to ' + node.name);

    // Re-validate this node
    const validation = await validateContent(fixedContent);
    figma.ui.postMessage({
      type: 'node-updated',
      nodeId,
      validation,
    });
  } catch (error) {
    figma.notify('Error applying fix: ' + error.message);
  }
}

/**
 * Select and zoom to a specific node
 */
function selectNode(nodeId: string) {
  const node = figma.getNodeById(nodeId);

  if (!node) {
    figma.notify('Layer not found');
    return;
  }

  figma.currentPage.selection = [node as SceneNode];
  figma.viewport.scrollAndZoomIntoView([node as SceneNode]);
}
