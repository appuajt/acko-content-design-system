# ACKO Content Validator - Figma Plugin

Validate all text layers in your Figma designs against ACKO's content design guidelines - before handoff to development!

## 🎯 Features

- ✅ **Scan entire pages** - Validate all text layers at once
- ✅ **Scan selection** - Validate only selected layers
- ✅ **Real-time scoring** - 0-100 score for each layer
- ✅ **Violation details** - See exactly what's wrong and why
- ✅ **One-click fixes** - Apply suggested fixes directly to layers
- ✅ **Jump to layer** - Click any violation to select and zoom to that layer
- ✅ **Summary stats** - See overall quality metrics

## 📦 Installation

### Option 1: Install from Figma Community (Coming Soon)
Search for "ACKO Content Validator" in Figma Community

### Option 2: Install Locally (Development)

1. **Build the plugin:**
   ```bash
   cd figma-plugin
   npm install
   npm run build
   ```

2. **In Figma:**
   - Go to Menu → Plugins → Development → Import plugin from manifest
   - Select the `manifest.json` file from this folder
   - The plugin will appear in your Plugins menu

3. **Start backend API:**
   ```bash
   cd ../backend
   npm run dev
   # Server must be running on http://localhost:5000
   ```

## 🚀 Usage

### Basic Workflow

1. **Open your Figma file** with UI designs

2. **Run the plugin:**
   - Menu → Plugins → Development → ACKO Content Validator

3. **Choose scan type:**
   - **Scan Page**: Validates all text layers on current page
   - **Scan Selection**: Validates only selected text layers

4. **Review results:**
   - See overall score and violation count
   - Each layer shows its score (0-100)
   - Violations listed with severity (Error/Warning/Suggestion)

5. **Apply fixes:**
   - Click "Apply Fix" button on any violation
   - Fix is applied directly to the layer
   - Layer is re-validated automatically

6. **Navigate to issues:**
   - Click any layer card to select and zoom to it in Figma
   - Fix issues directly in Figma
   - Re-run scan to verify

### Example: Onboarding Flow Validation

```
1. Open onboarding screens (12 frames)
2. Click "Scan Page"
3. Plugin scans all text layers across all frames
4. Results show:
   - Average score: 78/100
   - 45 layers scanned
   - 8 violations found

5. Click first violation:
   - Layer: "Welcome Heading"
   - Issue: [ERROR] Use sentence case
   - Context: "Get The Best Coverage"
   - Suggestion: "Get the best coverage"
   
6. Click "Apply Fix"
   - Text updated in Figma
   - Score improves to 95/100

7. Repeat for remaining violations
8. Final score: 98/100 ✅
9. Ready for handoff!
```

## 📊 Validation Rules

The plugin checks for:

### Voice & Tone
- ✅ First-person voice ("we" not "ACKO")
- ✅ Active voice (not passive)
- ✅ No insurance jargon
- ✅ No overpromising ("best", "guaranteed")

### Formatting
- ✅ Sentence case (not title case)
- ✅ Action-oriented CTAs
- ✅ Limited exclamation marks

### Error Messages
- ✅ Resolution path provided
- ✅ No user-blaming language

## 🎨 Score Interpretation

| Score | Color | Meaning |
|-------|-------|---------|
| 90-100 | Green | Excellent - Ready to ship |
| 70-89 | Yellow | Good - Minor improvements recommended |
| 50-69 | Orange | Needs work - Address warnings |
| 0-49 | Red | Poor - Major revisions required |

## 🔧 Configuration

### API Endpoint

By default, the plugin connects to `http://localhost:5000/acko-validator`

To change the endpoint, edit `src/code.ts`:

```typescript
const API_ENDPOINT = 'https://your-api-url.com/acko-validator';
```

Then rebuild:
```bash
npm run build
```

### Network Access

The plugin requests network access to the validation API. Figma will ask for permission on first run.

Allowed domains are configured in `manifest.json`:
```json
"networkAccess": {
  "allowedDomains": [
    "http://localhost:5000",
    "https://*.acko.com"
  ]
}
```

## 🐛 Troubleshooting

### Plugin shows "API error"

**Problem:** Plugin can't reach the validation API

**Solution:**
1. Make sure backend is running:
   ```bash
   cd backend
   npm run dev
   ```

2. Test API manually:
   ```bash
   curl http://localhost:5000/acko-validator/health
   ```

3. Check Figma's network permissions (Settings → Plugins)

### "No violations found" but content has issues

**Problem:** Content isn't being sent to API

**Solution:**
1. Check browser console (Plugins → Development → Open Console)
2. Look for network errors
3. Verify API endpoint URL is correct

### Fixes not applying

**Problem:** Plugin can't modify text layers

**Solution:**
1. Make sure layers aren't locked
2. Check if text uses custom fonts (may need to load font first)
3. Try unlocking the layer and re-running

### Plugin crashes on large files

**Problem:** Too many text layers to process

**Solution:**
1. Use "Scan Selection" instead of "Scan Page"
2. Validate one section at a time
3. Consider breaking large files into smaller pages

## 📝 Development

### Project Structure

```
figma-plugin/
├── manifest.json       # Plugin configuration
├── package.json        # Dependencies
├── tsconfig.json       # TypeScript config
├── src/
│   ├── code.ts        # Main plugin code (runs in Figma sandbox)
│   └── ui.html        # Plugin UI (HTML + CSS + JS)
├── dist/              # Built files (generated)
│   ├── code.js
│   └── ui.html
└── README.md          # This file
```

### Build Commands

```bash
# Install dependencies
npm install

# Build once
npm run build

# Watch mode (rebuild on changes)
npm run watch
```

### Testing

1. Make changes to `src/code.ts` or `src/ui.html`
2. Run `npm run build`
3. In Figma: Right-click plugin → "Reload plugin"
4. Test your changes

## 🚀 Publishing to Figma Community

1. **Prepare assets:**
   - Plugin icon (128x128)
   - Cover image (1920x960)
   - Screenshots

2. **Update manifest:**
   ```json
   {
     "name": "ACKO Content Validator",
     "id": "your-plugin-id",
     "api": "1.0.0"
   }
   ```

3. **Submit:**
   - Menu → Plugins → Development → Publish new plugin
   - Follow Figma's publishing guidelines

## 💡 Tips & Best Practices

### Before Design Handoff

✅ Run validation on all screens  
✅ Fix all ERROR violations  
✅ Review WARNING violations  
✅ Document any intentional exceptions  

### During Design Reviews

✅ Share validation report with team  
✅ Use scores to track quality over time  
✅ Create design system documentation from common violations  

### For Design Systems

✅ Validate component library labels  
✅ Document validated text patterns  
✅ Update guidelines based on validation insights  

## 🔒 Privacy & Security

- ✅ Text content sent only to your validation API
- ✅ No data stored or logged by plugin
- ✅ Network access only to specified domains
- ✅ All validation happens server-side

## 📚 Related Documentation

- [Backend API Documentation](../backend/src/lib/acko-content-validator/README.md)
- [Chrome Extension](../browser-extension/README.md)
- [Integration Guide](../ACKO_VALIDATOR_INTEGRATION.md)
- [Complete System Guide](../ACKO_VALIDATOR_COMPLETE_GUIDE.md)

## 🆘 Support

**Issues?** Check the troubleshooting section above

**Questions?** See the complete documentation in parent directory

**API Problems?** Make sure backend is running and accessible

---

**Built with ❤️ for ACKO Design Team**
