# ACKO Content Validator Extension - Installation Guide

Complete step-by-step guide to install and use the ACKO Content Validator browser extension.

## 📋 Prerequisites

1. **Chrome or Edge browser** (version 88+)
2. **ACKO Validation API** running locally or deployed

## 🚀 Quick Start (5 minutes)

### Step 1: Start the API Server

```bash
# Navigate to your project backend
cd /Users/kanika.oberoi/Documents/GitHub/growth-labs-omni-media/backend

# Install dependencies (if not already done)
npm install

# Start the development server
npm run dev

# Server should be running on http://localhost:5000
# You should see: "Server running on port 5000"
```

Keep this terminal open - the server must be running for the extension to work.

### Step 2: Load Extension in Chrome

1. **Open Chrome Extensions page:**
   - Type `chrome://extensions/` in your address bar, or
   - Click menu (⋮) → More Tools → Extensions

2. **Enable Developer Mode:**
   - Toggle the "Developer mode" switch in the top-right corner

3. **Load the extension:**
   - Click "Load unpacked" button
   - Navigate to and select the `browser-extension` folder:
     ```
     /Users/kanika.oberoi/Documents/GitHub/growth-labs-omni-media/browser-extension
     ```
   - Click "Select"

4. **Verify installation:**
   - You should see "ACKO Content Validator" in your extensions list
   - The extension icon should appear in your Chrome toolbar
   - Status should show "Enabled"

### Step 3: Test the Extension

1. **Open any webpage** (try Medium.com, LinkedIn, or any content-heavy site)

2. **Select some text** on the page

3. **Validate using any method:**

   **Method A: Right-click**
   - Right-click the selected text
   - Choose "Validate with ACKO"

   **Method B: Keyboard shortcut**
   - Press `Alt+Shift+V` (Windows/Linux)
   - Press `Option+Shift+V` (Mac)

   **Method C: Alt+Click**
   - Select text
   - Hold `Alt` and click anywhere

4. **See results:**
   - A validation panel slides in from the right
   - Shows score (0-100) and any violations
   - Click the copy button to copy the report

## 🎯 Extension Features

### 1. Validate Selected Text

**How it works:**
- Select any text on any webpage
- Use right-click menu, keyboard shortcut, or Alt+Click
- Get instant validation feedback

**Example:**
```
Selected: "Click Here To Get Started!"

Results:
Score: 62/100

Issues:
[ERROR] Use sentence case
  Context: "Click Here To Get Started!"
  Suggestion: "Click here to get started"

[SUGGESTION] Limit exclamation marks
  Context: "!"
  Suggestion: "."
```

### 2. Manual Validation

**How it works:**
- Click the extension icon in toolbar
- Paste or type content
- Select content type (UI Copy, Marketing, CTA, etc.)
- Click "Validate"

**Use cases:**
- Writing new copy in a doc
- Checking email drafts
- Validating Figma designs
- Testing marketing copy

### 3. Page Scanning

**How it works:**
- Click extension icon
- Click "Scan Entire Page"
- Extension validates all text elements on the page
- Get aggregate score and individual element reports

**Use cases:**
- Auditing live websites
- Checking landing pages
- QA before launch
- Competitive analysis

### 4. Auto-Fix

**How it works:**
- Enable "Auto-fix violations" in settings
- Extension automatically fixes common issues
- Fixed content copied to clipboard
- Paste the improved version

**What gets auto-fixed:**
- Sentence case conversion
- Jargon replacement
- Exclamation mark removal
- Third-person → first-person

## ⚙️ Configuration

### Settings

Click the extension icon → Settings section:

| Setting | Default | Description |
|---------|---------|-------------|
| Auto-fix violations | OFF | Automatically fix common issues |
| Show on selection (Alt+Click) | ON | Enable Alt+Click validation |
| API Endpoint | `http://localhost:5000` | Validation API URL |

### Custom API Endpoint

**For production or remote API:**

1. Click extension icon
2. Change "API Endpoint" to your API URL
   - Example: `https://api.acko.com`
   - Example: `http://192.168.1.100:5000`
3. Settings save automatically

### Keyboard Shortcuts

**Default shortcuts:**
- `Alt+Shift+V` - Validate selection

**To customize:**
1. Go to `chrome://extensions/shortcuts`
2. Find "ACKO Content Validator"
3. Click the edit icon
4. Set your preferred shortcut

## 🔧 Troubleshooting

### Issue: "Error validating content"

**Symptoms:**
- Red error message in validation panel
- "API error: 500" or connection refused

**Solution:**
```bash
# Check if backend is running
cd backend
npm run dev

# Verify API is accessible
curl http://localhost:5000/acko-validator/health

# Should return: {"success":true,"data":{"status":"healthy"}}
```

### Issue: Extension not showing in toolbar

**Solution:**
1. Go to `chrome://extensions/`
2. Find "ACKO Content Validator"
3. Click the pin icon to pin it to toolbar

### Issue: Right-click menu not appearing

**Solution:**
1. Refresh the webpage (`Ctrl+R` or `Cmd+R`)
2. Reload the extension:
   - Go to `chrome://extensions/`
   - Click reload icon on ACKO extension
3. If still not working, remove and re-add the extension

### Issue: Alt+Click not working

**Solution:**
1. Check if setting is enabled:
   - Click extension icon
   - Make sure "Show on selection (Alt+Click)" is toggled ON
2. Some websites capture Alt+Click - try keyboard shortcut instead

### Issue: Validation panel not appearing

**Solution:**
1. Check browser console:
   - Press `F12` to open DevTools
   - Go to Console tab
   - Look for errors
2. Make sure you selected at least 3 characters
3. Try refreshing the page

### Issue: "CORS error" in console

**Solution:**
The backend CORS settings need to allow your domain:

```typescript
// backend/src/index.ts
app.use(cors({
  origin: '*', // Allow all origins (development only)
  // OR for specific domains:
  // origin: ['chrome-extension://*', 'http://localhost:3000'],
  credentials: true,
}));
```

## 🎨 Using on Different Websites

### Google Docs
1. Select text in your document
2. Right-click → "Validate with ACKO"
3. Panel appears with validation

### Figma (Web)
1. Copy text from Figma
2. Click extension icon
3. Paste into manual validation
4. Get instant feedback

### Notion
1. Highlight text in Notion
2. Press `Alt+Shift+V`
3. See validation results

### LinkedIn Posts
1. Write your post
2. Select the text
3. Alt+Click to validate
4. Fix issues before posting

### Email (Gmail, Outlook)
1. Compose email
2. Select subject or body text
3. Right-click → Validate
4. Improve before sending

## 📊 Understanding Results

### Score Interpretation

| Score | Meaning | Action |
|-------|---------|--------|
| 90-100 | Excellent | Ready to publish |
| 70-89 | Good | Minor improvements recommended |
| 50-69 | Needs work | Address warnings before publishing |
| 0-49 | Poor | Major revisions required |

### Violation Severities

**🔴 ERROR (Red)**
- Must fix before publishing
- Violates core ACKO guidelines
- Examples: Third-person voice, insurance jargon

**🟡 WARNING (Yellow)**
- Should fix if possible
- Quality improvements
- Examples: Passive voice, long sentences

**⚪ SUGGESTION (Gray)**
- Nice to have
- Best practice recommendations
- Examples: Exclamation marks, readability

### Common Violations

| Violation | Example | Fix |
|-----------|---------|-----|
| Third-person voice | "ACKO provides..." | "We provide..." |
| Insurance jargon | "IDV of your vehicle" | "Value of your vehicle" |
| Title case | "Get Your Quote Now" | "Get your quote now" |
| Passive voice | "Your claim will be processed" | "We'll process your claim" |
| Overpromising | "Best insurance guaranteed!" | "Comprehensive insurance" |

## 🔒 Privacy & Security

**What the extension does:**
- ✅ Sends selected text to YOUR API only
- ✅ Stores settings in Chrome sync storage
- ✅ Runs validation locally via your API

**What the extension DOES NOT do:**
- ❌ Send data to external servers
- ❌ Track your browsing
- ❌ Collect analytics
- ❌ Store your content

## 📦 Uninstallation

**To remove the extension:**

1. Go to `chrome://extensions/`
2. Find "ACKO Content Validator"
3. Click "Remove"
4. Confirm removal

**Your settings and data:**
- All stored settings are deleted
- No data remains after uninstallation

## 🆕 Updates

**To update the extension:**

1. Pull latest changes:
   ```bash
   cd browser-extension
   git pull origin main
   ```

2. Reload extension:
   - Go to `chrome://extensions/`
   - Click reload icon on ACKO extension

3. Verify new version in extension details

## 💡 Tips & Tricks

### Tip 1: Quick Validation Workflow
- Select text → Alt+Click → Review → Copy fixed version
- Total time: 5 seconds

### Tip 2: Batch Content Audit
- Open your website
- Click "Scan Entire Page"
- Get full audit report
- Export to share with team

### Tip 3: Pre-publish Checklist
1. Write content
2. Validate with extension
3. Fix all errors (red)
4. Review warnings (yellow)
5. Publish with confidence

### Tip 4: Integration with Writing Tools
- Write in Google Docs
- Validate with extension
- Fix issues inline
- Export final version

### Tip 5: Team Alignment
- Share validation reports
- Use same guidelines
- Maintain consistent voice
- Build content library

## 🚀 Next Steps

Now that your extension is installed:

1. **Test on real content:**
   - Open your website
   - Validate existing copy
   - Identify common issues

2. **Set up your workflow:**
   - Decide when to validate (before/after writing)
   - Customize keyboard shortcuts
   - Configure auto-fix if needed

3. **Share with your team:**
   - Document your API endpoint
   - Share this guide
   - Create team standards

4. **Advanced usage:**
   - Integrate with CI/CD
   - Build custom rules
   - Add to style guide

## 📞 Support

**Need help?**
- 📖 [Full Documentation](../ACKO_VALIDATOR_INTEGRATION.md)
- 🐛 [Report Issues](https://github.com/your-repo/issues)
- 💬 Slack: #acko-content-validator
- 📧 Email: support@acko.com

---

**Congratulations! You're ready to validate content like a pro!** 🎉
