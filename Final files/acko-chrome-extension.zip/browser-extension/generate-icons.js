/**
 * Generate placeholder icons for the ACKO extension
 * Creates simple SVG-based PNG icons
 */

const fs = require('fs');
const path = require('path');

// Create icons directory
const iconsDir = path.join(__dirname, 'icons');
if (!fs.existsSync(iconsDir)) {
  fs.mkdirSync(iconsDir, { recursive: true });
}

// Generate SVG icons at different sizes
const sizes = [16, 32, 48, 128];

const generateSVG = (size) => `
<svg width="${size}" height="${size}" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#6841E6;stop-opacity:1" />
      <stop offset="100%" style="stop-color:#582FD2;stop-opacity:1" />
    </linearGradient>
  </defs>

  <!-- Rounded rectangle background -->
  <rect width="${size}" height="${size}" rx="${size * 0.2}" fill="url(#grad)" />

  <!-- Checkmark -->
  <polyline points="${size * 0.25},${size * 0.5} ${size * 0.42},${size * 0.68} ${size * 0.75},${size * 0.32}"
    stroke="white"
    stroke-width="${size * 0.08}"
    fill="none"
    stroke-linecap="round"
    stroke-linejoin="round" />

  ${size >= 48 ? `
  <!-- Letter A for larger sizes -->
  <text x="${size * 0.5}" y="${size * 0.58}"
    font-family="system-ui, -apple-system, sans-serif"
    font-size="${size * 0.35}"
    font-weight="bold"
    fill="white"
    text-anchor="middle">A</text>
  ` : ''}
</svg>
`;

console.log('Generating ACKO extension icons...\n');

sizes.forEach(size => {
  const svg = generateSVG(size);
  const filename = `icon${size}.svg`;
  const filepath = path.join(iconsDir, filename);

  fs.writeFileSync(filepath, svg.trim());
  console.log(`✓ Created ${filename}`);
});

console.log('\n✓ All icons generated successfully!');
console.log('\nNOTE: SVG icons work in Chrome. For PNG icons:');
console.log('1. Open browser-extension/create-icons.html in a browser');
console.log('2. Right-click each canvas and save as PNG');
console.log('3. Or use an SVG-to-PNG converter online\n');
