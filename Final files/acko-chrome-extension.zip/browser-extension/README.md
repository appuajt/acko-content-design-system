# ACKO Content Validator - Browser Extension

A Chrome/Edge extension that validates web content against ACKO's content design system guidelines - like Grammarly for ACKO content!

![Version](https://img.shields.io/badge/version-1.0.0-blue.svg)
![License](https://img.shields.io/badge/license-MIT-green.svg)

## Features

✅ **Real-time validation** - Validate any selected text on any webpage  
✅ **Context menu integration** - Right-click to validate  
✅ **Keyboard shortcuts** - `Alt+Shift+V` to validate selection  
✅ **Alt+Click validation** - Hold Alt and click to validate selection  
✅ **Page scanning** - Scan entire pages for ACKO guideline violations  
✅ **Inline results** - Beautiful sliding panel with detailed feedback  
✅ **Auto-fix support** - Automatically fix common violations  
✅ **Score tracking** - Get a 0-100 score for content quality  
✅ **Copy reports** - Export validation reports to clipboard  

## Installation

### From Source (Development)

1. **Clone the repository:**
   ```bash
   cd browser-extension
   ```

2. **Make sure your API server is running:**
   ```bash
   cd ../backend
   npm run dev
   # Server should be running on http://localhost:5000
   ```

3. **Load extension in Chrome:**
   - Open Chrome and go to `chrome://extensions/`
   - Enable "Developer mode" (toggle in top-right)
   - Click "Load unpacked"
   - Select the `browser-extension` directory
   - The ACKO Content Validator icon should appear in your extensions

4. **Load extension in Edge:**
   - Open Edge and go to `edge://extensions/`
   - Enable "Developer mode"
   - Click "Load unpacked"
   - Select the `browser-extension` directory

### From Chrome Web Store (Coming Soon)

Once published, install directly from the Chrome Web Store.

## Usage

### Method 1: Select and Validate

1. Select any text on a webpage
2. Right-click and choose "Validate with ACKO"
3. Or press `Alt+Shift+V`
4. Or hold `Alt` and click anywhere after selecting

A validation panel will slide in from the right showing:
- **Score** (0-100)
- **Violations** with severity badges
- **Suggestions** for fixes
- **Copy report** button

### Method 2: Manual Input

1. Click the ACKO extension icon in your toolbar
2. Type or paste content into the text area
3. Select content type (UI Copy, Marketing, CTA, etc.)
4. Click "Validate"

### Method 3: Page Scan

1. Click the ACKO extension icon
2. Click "Scan Entire Page"
3. Get a report of all text elements on the page

## Settings

Click the extension icon to access settings:

- **Auto-fix violations** - Automatically fix common issues
- **Show on selection (Alt+Click)** - Enable/disable Alt+Click shortcut
- **API Endpoint** - Change the validation API URL (default: `http://localhost:5000`)

## Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| `Alt+Shift+V` | Validate selected text |
| `Alt+Click` | Validate selection after highlighting |

You can customize shortcuts in `chrome://extensions/shortcuts`

## Content Types

The extension supports validation for:

- **UI Copy** - Buttons, labels, tooltips
- **Marketing** - Landing pages, ad copy
- **Error Messages** - Form validation, error states
- **CTAs** - Call-to-action buttons
- **Headings** - Page and section titles
- **Body Text** - Paragraphs, descriptions
- **Labels** - Form labels, badges
- **Notifications** - Toasts, alerts
- **SEO Content** - Blog posts, articles

## ACKO Guidelines Checked

The extension validates against these rules:

### Voice & Tone
- ✅ Use "we" and "our" (not third-person)
- ✅ Active voice (not passive)
- ✅ Plain language (no jargon)
- ✅ Realistic claims (no overpromising)
- ✅ Clear and direct (not playful)

### Formatting
- ✅ Sentence case (not title case or ALL CAPS)
- ✅ Action-oriented CTAs
- ✅ Limited exclamation marks

### Error Messages
- ✅ Resolution path provided
- ✅ No user-blaming

## Screenshots

### Validation Panel
![Validation Panel](screenshots/panel.png)

### Context Menu
![Context Menu](screenshots/context-menu.png)

### Popup Interface
![Popup](screenshots/popup.png)

## Development

### Project Structure

```
browser-extension/
├── manifest.json          # Extension manifest
├── src/
│   ├── popup.html        # Extension popup UI
│   ├── popup.js          # Popup logic
│   ├── content.js        # Content script (runs on pages)
│   ├── background.js     # Service worker
│   └── styles.css        # Content script styles
├── icons/                # Extension icons
└── README.md
```

### Building for Production

To package the extension:

```bash
cd browser-extension
zip -r acko-validator-extension.zip . -x "*.git*" -x "screenshots/*" -x "*.DS_Store"
```

This creates a `.zip` file you can upload to the Chrome Web Store.

## API Configuration

The extension connects to your ACKO validation API. Default endpoint: `http://localhost:5000`

To change the endpoint:
1. Click the extension icon
2. Scroll to Settings
3. Update "API Endpoint" field
4. Settings are saved automatically

For production, update to your deployed API URL.

## Permissions

The extension requires these permissions:

- `activeTab` - Access current tab content
- `contextMenus` - Add right-click menu items
- `storage` - Save user settings
- `scripting` - Inject content scripts
- `host_permissions` - Connect to validation API

## Privacy

- ✅ No data is collected or stored externally
- ✅ All validation happens via your API
- ✅ Selected text is sent only to your configured API endpoint
- ✅ Settings stored locally in Chrome sync storage
- ✅ No tracking, no analytics

## Troubleshooting

### "Error validating content"

**Problem:** API connection failed  
**Solution:** Make sure your backend is running on `http://localhost:5000`

```bash
cd backend
npm run dev
```

### Extension not appearing

**Problem:** Extension not loaded  
**Solution:** 
1. Go to `chrome://extensions/`
2. Make sure "Developer mode" is enabled
3. Click "Reload" on the ACKO Content Validator extension

### Alt+Click not working

**Problem:** Shortcut disabled  
**Solution:**
1. Click extension icon
2. Enable "Show on selection (Alt+Click)" in Settings

### No validation results

**Problem:** Text too short or API error  
**Solution:**
- Select at least 3 characters
- Check browser console for errors (`F12` → Console)
- Verify API endpoint in settings

## Roadmap

- [ ] Firefox support
- [ ] Safari support
- [ ] Offline mode with local validation
- [ ] Historical validation tracking
- [ ] Team collaboration features
- [ ] Integration with Google Docs
- [ ] Integration with Notion
- [ ] Custom rule configuration

## Contributing

Contributions welcome! Please:

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

MIT License - see LICENSE file for details

## Support

- **Issues:** [GitHub Issues](https://github.com/your-repo/issues)
- **Email:** support@acko.com
- **Docs:** [Full Documentation](../ACKO_VALIDATOR_INTEGRATION.md)

---

Made with ❤️ for ACKO
