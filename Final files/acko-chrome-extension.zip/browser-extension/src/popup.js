// Popup script for ACKO Content Validator extension

let settings = {
  autoFix: false,
  altClick: true,
  apiEndpoint: 'http://localhost:5000',
};

// Load settings from storage
chrome.storage.sync.get(['settings'], (result) => {
  if (result.settings) {
    settings = { ...settings, ...result.settings };
    updateUI();
  }
});

function updateUI() {
  document.getElementById('autoFixToggle').classList.toggle('active', settings.autoFix);
  document.getElementById('altClickToggle').classList.toggle('active', settings.altClick);
  document.getElementById('apiEndpoint').value = settings.apiEndpoint;
}

function saveSettings() {
  chrome.storage.sync.set({ settings });
}

// Toggle handlers
document.getElementById('autoFixToggle').addEventListener('click', function() {
  settings.autoFix = !settings.autoFix;
  this.classList.toggle('active');
  saveSettings();
});

document.getElementById('altClickToggle').addEventListener('click', function() {
  settings.altClick = !settings.altClick;
  this.classList.toggle('active');
  saveSettings();
});

document.getElementById('apiEndpoint').addEventListener('change', function() {
  settings.apiEndpoint = this.value;
  saveSettings();
});

// Validate selected text button
document.getElementById('validateSelectionBtn').addEventListener('click', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  chrome.tabs.sendMessage(tab.id, { action: 'getSelection' }, (response) => {
    if (response && response.text) {
      document.getElementById('contentInput').value = response.text;
      validateContent(response.text);
    } else {
      showError('No text selected on the page');
    }
  });
});

// Validate page button
document.getElementById('validatePageBtn').addEventListener('click', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  chrome.tabs.sendMessage(tab.id, { action: 'scanPage' }, (response) => {
    if (response && response.content) {
      showPageScanResults(response.content);
    } else {
      showError('Could not scan page content');
    }
  });
});

// Manual validate button
document.getElementById('validateBtn').addEventListener('click', () => {
  const content = document.getElementById('contentInput').value.trim();

  if (!content) {
    showError('Please enter some content to validate');
    return;
  }

  validateContent(content);
});

async function validateContent(content) {
  const contentType = document.getElementById('contentType').value;
  const resultDiv = document.getElementById('result');

  // Show loader
  resultDiv.innerHTML = `
    <div class="loader">
      <div class="loader-spinner"></div>
      <div>Validating content...</div>
    </div>
  `;
  resultDiv.classList.add('show');

  try {
    const endpoint = settings.autoFix
      ? `${settings.apiEndpoint}/acko-validator/validate/auto-fix`
      : `${settings.apiEndpoint}/acko-validator/validate`;

    const response = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content, contentType }),
    });

    if (!response.ok) {
      throw new Error(`API error: ${response.status}`);
    }

    const { data } = await response.json();

    if (settings.autoFix && data.fixedContent) {
      showAutoFixedResults(data);
    } else {
      showValidationResults(data);
    }
  } catch (error) {
    showError(`Validation failed: ${error.message}`);
  }
}

function showValidationResults(data) {
  const resultDiv = document.getElementById('result');

  const scoreClass = data.score >= 80 ? 'good' : data.score >= 60 ? 'medium' : 'poor';

  let html = `
    <div class="score ${scoreClass}">
      <div class="score-value">${Math.round(data.score)}</div>
      <div class="score-label">Validation Score</div>
    </div>
  `;

  if (data.violations && data.violations.length > 0) {
    html += '<div class="violations">';

    data.violations.forEach(violation => {
      html += `
        <div class="violation ${violation.severity}">
          <div class="violation-severity">${violation.severity}</div>
          <div class="violation-message">${violation.message}</div>
          <div class="violation-context">"${violation.context}"</div>
          ${violation.suggestion ? `
            <div class="violation-suggestion">
              💡 Suggestion: "${violation.suggestion}"
            </div>
          ` : ''}
        </div>
      `;
    });

    html += '</div>';
  } else {
    html += `
      <div class="no-violations">
        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
        </svg>
        <div style="font-weight: 600; margin-bottom: 4px;">Perfect!</div>
        <div style="font-size: 12px;">Content follows ACKO guidelines</div>
      </div>
    `;
  }

  resultDiv.innerHTML = html;
  resultDiv.classList.add('show');
}

function showAutoFixedResults(data) {
  const resultDiv = document.getElementById('result');

  const scoreClass = data.validation.score >= 80 ? 'good' : data.validation.score >= 60 ? 'medium' : 'poor';

  let html = `
    <div class="score ${scoreClass}">
      <div class="score-value">${Math.round(data.validation.score)}</div>
      <div class="score-label">Score After Auto-Fix</div>
    </div>
  `;

  if (data.appliedFixes && data.appliedFixes.length > 0) {
    html += `
      <div style="background: #F0FDF4; padding: 12px; border-radius: 6px; margin-bottom: 12px; font-size: 13px;">
        <div style="font-weight: 600; color: #15803D; margin-bottom: 4px;">
          ✓ Applied ${data.appliedFixes.length} fix${data.appliedFixes.length > 1 ? 'es' : ''}
        </div>
        <div style="color: #6B7280; font-size: 12px;">
          Fixed content has been copied to clipboard
        </div>
      </div>
    `;

    // Copy fixed content to clipboard
    if (data.fixedContent) {
      navigator.clipboard.writeText(data.fixedContent);
      document.getElementById('contentInput').value = data.fixedContent;
    }
  }

  if (data.validation.violations && data.validation.violations.length > 0) {
    html += '<div class="violations">';

    data.validation.violations.forEach(violation => {
      html += `
        <div class="violation ${violation.severity}">
          <div class="violation-severity">${violation.severity}</div>
          <div class="violation-message">${violation.message}</div>
          <div class="violation-context">"${violation.context}"</div>
        </div>
      `;
    });

    html += '</div>';
  } else {
    html += `
      <div class="no-violations">
        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
        </svg>
        <div style="font-weight: 600; margin-bottom: 4px;">All Fixed!</div>
        <div style="font-size: 12px;">Content now follows ACKO guidelines</div>
      </div>
    `;
  }

  resultDiv.innerHTML = html;
  resultDiv.classList.add('show');
}

function showPageScanResults(items) {
  const resultDiv = document.getElementById('result');

  const totalItems = items.length;
  const validItems = items.filter(i => i.score >= 80).length;
  const avgScore = items.reduce((sum, i) => sum + i.score, 0) / totalItems;

  const scoreClass = avgScore >= 80 ? 'good' : avgScore >= 60 ? 'medium' : 'poor';

  let html = `
    <div class="score ${scoreClass}">
      <div class="score-value">${Math.round(avgScore)}</div>
      <div class="score-label">Page Average Score</div>
      <div style="font-size: 12px; margin-top: 8px; opacity: 0.8;">
        ${validItems}/${totalItems} elements valid
      </div>
    </div>
  `;

  html += '<div class="violations" style="max-height: 250px;">';

  items.forEach((item, idx) => {
    if (item.violations.length > 0) {
      html += `
        <div style="background: #F9FAFB; padding: 10px; border-radius: 6px; margin-bottom: 8px;">
          <div style="font-size: 11px; font-weight: 600; margin-bottom: 6px; color: #6B7280;">
            Element ${idx + 1} (Score: ${Math.round(item.score)})
          </div>
          ${item.violations.slice(0, 2).map(v => `
            <div class="violation ${v.severity}" style="margin-bottom: 4px; padding: 8px;">
              <div class="violation-severity">${v.severity}</div>
              <div class="violation-message" style="font-size: 12px;">${v.message}</div>
            </div>
          `).join('')}
          ${item.violations.length > 2 ? `
            <div style="font-size: 11px; color: #6B7280; margin-top: 4px;">
              +${item.violations.length - 2} more
            </div>
          ` : ''}
        </div>
      `;
    }
  });

  html += '</div>';

  resultDiv.innerHTML = html;
  resultDiv.classList.add('show');
}

function showError(message) {
  const resultDiv = document.getElementById('result');

  resultDiv.innerHTML = `
    <div style="background: #FFF1F2; padding: 16px; border-radius: 6px; border-left: 3px solid #BE123C;">
      <div style="font-weight: 600; color: #BE123C; margin-bottom: 4px;">Error</div>
      <div style="font-size: 13px; color: #6B7280;">${message}</div>
    </div>
  `;
  resultDiv.classList.add('show');
}

// Help link
document.getElementById('helpLink').addEventListener('click', (e) => {
  e.preventDefault();
  chrome.tabs.create({
    url: 'https://github.com/your-repo/acko-validator#readme'
  });
});

// Listen for keyboard shortcut
chrome.commands.onCommand.addListener((command) => {
  if (command === 'validate-selection') {
    document.getElementById('validateSelectionBtn').click();
  }
});
