// Content script - runs on all pages
// Provides text selection validation and inline validation panel

let validationPanel = null;
let settings = {
  altClick: true,
  apiEndpoint: 'http://localhost:5000',
};

// Load settings
chrome.storage.sync.get(['settings'], (result) => {
  if (result.settings) {
    settings = { ...settings, ...result.settings };
  }
});

// Listen for settings updates
chrome.storage.onChanged.addListener((changes) => {
  if (changes.settings) {
    settings = { ...settings, ...changes.settings.newValue };
  }
});

// Create validation panel
function createValidationPanel() {
  if (validationPanel) {
    validationPanel.remove();
  }

  const panel = document.createElement('div');
  panel.id = 'acko-validation-panel';
  panel.style.cssText = `
    position: fixed;
    top: 80px;
    right: 20px;
    width: 380px;
    max-height: 600px;
    overflow-y: auto;
    background: white;
    border: 2px solid #6841E6;
    border-radius: 10px;
    padding: 0;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.15);
    z-index: 2147483647;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    animation: slideIn 0.3s ease-out;
  `;

  const style = document.createElement('style');
  style.textContent = `
    @keyframes slideIn {
      from {
        transform: translateX(100%);
        opacity: 0;
      }
      to {
        transform: translateX(0);
        opacity: 1;
      }
    }

    #acko-validation-panel::-webkit-scrollbar {
      width: 6px;
    }

    #acko-validation-panel::-webkit-scrollbar-track {
      background: #f1f1f1;
    }

    #acko-validation-panel::-webkit-scrollbar-thumb {
      background: #6841E6;
      border-radius: 3px;
    }

    #acko-validation-panel::-webkit-scrollbar-thumb:hover {
      background: #582FD2;
    }
  `;

  document.head.appendChild(style);
  document.body.appendChild(panel);

  validationPanel = panel;
  return panel;
}

// Show validation results in panel
function showValidationInPanel(data, selectedText) {
  const panel = createValidationPanel();

  const scoreClass = data.score >= 80 ? '#15803D' : data.score >= 60 ? '#B45309' : '#BE123C';
  const scoreBg = data.score >= 80 ? '#F0FDF4' : data.score >= 60 ? '#FFFBEB' : '#FFF1F2';

  let html = `
    <div style="background: linear-gradient(135deg, #6841E6 0%, #582FD2 100%); padding: 16px; border-radius: 8px 8px 0 0; color: white;">
      <div style="display: flex; justify-content: space-between; align-items: center;">
        <div style="font-weight: 600; font-size: 14px;">ACKO Validation</div>
        <button id="acko-close-btn" style="background: rgba(255,255,255,0.2); border: none; color: white; width: 28px; height: 28px; border-radius: 50%; cursor: pointer; font-size: 18px; line-height: 1;">×</button>
      </div>
    </div>

    <div style="padding: 16px;">
      <div style="background: ${scoreBg}; padding: 16px; border-radius: 8px; text-align: center; margin-bottom: 16px;">
        <div style="font-size: 48px; font-weight: 700; color: ${scoreClass}; line-height: 1; margin-bottom: 4px;">
          ${Math.round(data.score)}
        </div>
        <div style="font-size: 12px; color: #6B7280; font-weight: 500;">VALIDATION SCORE</div>
      </div>

      <div style="background: #F9FAFB; padding: 12px; border-radius: 6px; margin-bottom: 16px; max-height: 100px; overflow-y: auto;">
        <div style="font-size: 11px; font-weight: 600; color: #6B7280; margin-bottom: 6px; text-transform: uppercase;">Selected Text</div>
        <div style="font-size: 13px; color: #0A0A0A; line-height: 1.5;">"${selectedText.substring(0, 200)}${selectedText.length > 200 ? '...' : ''}"</div>
      </div>

      ${data.violations.length === 0 ? `
        <div style="text-align: center; padding: 30px 20px; color: ${scoreClass};">
          <svg style="width: 48px; height: 48px; margin-bottom: 12px;" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
          </svg>
          <div style="font-weight: 600; font-size: 16px; margin-bottom: 4px;">Perfect!</div>
          <div style="font-size: 13px; opacity: 0.8;">Content follows ACKO guidelines</div>
        </div>
      ` : `
        <div style="margin-bottom: 8px;">
          <div style="font-size: 12px; font-weight: 600; color: #6B7280; margin-bottom: 8px;">
            ${data.violations.length} ISSUE${data.violations.length > 1 ? 'S' : ''} FOUND
          </div>
          ${data.violations.map(v => {
            const severityColor = v.severity === 'error' ? '#BE123C' : v.severity === 'warning' ? '#B45309' : '#6B7280';
            const severityBg = v.severity === 'error' ? '#FFF1F2' : v.severity === 'warning' ? '#FFFBEB' : '#F9FAFB';

            return `
              <div style="padding: 12px; margin-bottom: 8px; border-left: 3px solid ${severityColor}; background: ${severityBg}; border-radius: 4px;">
                <div style="background: ${severityColor}; color: white; display: inline-block; padding: 2px 8px; border-radius: 3px; font-size: 10px; font-weight: 600; text-transform: uppercase; margin-bottom: 6px;">
                  ${v.severity}
                </div>
                <div style="margin-bottom: 6px; font-size: 13px; font-weight: 500; color: #0A0A0A;">
                  ${v.message}
                </div>
                <div style="font-size: 12px; color: #6B7280; font-style: italic; margin-bottom: 4px;">
                  "${v.context}"
                </div>
                ${v.suggestion ? `
                  <div style="margin-top: 8px; padding-top: 8px; border-top: 1px solid rgba(0,0,0,0.1); font-size: 12px; color: #15803D;">
                    <span style="font-weight: 600;">💡 Suggestion:</span> "${v.suggestion}"
                  </div>
                ` : ''}
              </div>
            `;
          }).join('')}
        </div>
      `}

      <div style="margin-top: 16px; padding-top: 16px; border-top: 1px solid #E0E0E1;">
        <button id="acko-copy-report" style="width: 100%; padding: 10px; background: #F5F5F5; border: 1px solid #E0E0E1; border-radius: 6px; font-size: 13px; font-weight: 500; cursor: pointer; color: #474649;">
          Copy Report
        </button>
      </div>
    </div>
  `;

  panel.innerHTML = html;

  // Close button
  panel.querySelector('#acko-close-btn').addEventListener('click', () => {
    panel.style.animation = 'slideIn 0.3s ease-out reverse';
    setTimeout(() => {
      panel.remove();
      validationPanel = null;
    }, 300);
  });

  // Copy report button
  panel.querySelector('#acko-copy-report').addEventListener('click', () => {
    const report = generateTextReport(data, selectedText);
    navigator.clipboard.writeText(report);

    const btn = panel.querySelector('#acko-copy-report');
    btn.textContent = '✓ Copied!';
    btn.style.background = '#F0FDF4';
    btn.style.borderColor = '#BBF7D0';
    btn.style.color = '#15803D';

    setTimeout(() => {
      btn.textContent = 'Copy Report';
      btn.style.background = '#F5F5F5';
      btn.style.borderColor = '#E0E0E1';
      btn.style.color = '#474649';
    }, 2000);
  });

  // Close panel when clicking outside
  setTimeout(() => {
    document.addEventListener('click', function closeOnOutside(e) {
      if (validationPanel && !validationPanel.contains(e.target)) {
        validationPanel.remove();
        validationPanel = null;
        document.removeEventListener('click', closeOnOutside);
      }
    });
  }, 100);
}

function generateTextReport(data, selectedText) {
  let report = '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n';
  report += 'ACKO CONTENT VALIDATION REPORT\n';
  report += '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n';
  report += `Score: ${Math.round(data.score)}/100\n`;
  report += `Status: ${data.isValid ? '✓ Valid' : '✗ Needs fixes'}\n`;
  report += `Issues Found: ${data.violations.length}\n\n`;

  report += `Selected Text:\n"${selectedText}"\n\n`;

  if (data.violations.length > 0) {
    report += 'Issues:\n';
    report += '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n';

    data.violations.forEach((v, idx) => {
      report += `\n${idx + 1}. [${v.severity.toUpperCase()}] ${v.message}\n`;
      report += `   Context: "${v.context}"\n`;
      if (v.suggestion) {
        report += `   Suggestion: "${v.suggestion}"\n`;
      }
    });
  } else {
    report += '✓ No issues found - content follows ACKO guidelines!\n';
  }

  report += '\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n';
  report += `Generated: ${new Date().toLocaleString()}\n`;

  return report;
}

// Validate selected text
async function validateSelection() {
  const selectedText = window.getSelection().toString().trim();

  if (!selectedText) {
    return;
  }

  if (selectedText.length < 3) {
    return;
  }

  // Show loading state
  const panel = createValidationPanel();
  panel.innerHTML = `
    <div style="background: linear-gradient(135deg, #6841E6 0%, #582FD2 100%); padding: 16px; border-radius: 8px 8px 0 0; color: white;">
      <div style="font-weight: 600; font-size: 14px;">ACKO Validation</div>
    </div>
    <div style="padding: 40px; text-align: center;">
      <div style="border: 3px solid #F5F5F5; border-top: 3px solid #6841E6; border-radius: 50%; width: 40px; height: 40px; animation: spin 1s linear infinite; margin: 0 auto 16px;"></div>
      <div style="color: #6B7280; font-size: 14px;">Validating content...</div>
    </div>
  `;

  const style = document.createElement('style');
  style.textContent = '@keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }';
  document.head.appendChild(style);

  try {
    const response = await fetch(`${settings.apiEndpoint}/acko-validator/validate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        content: selectedText,
        contentType: 'ui-copy',
      }),
    });

    if (!response.ok) {
      throw new Error(`API error: ${response.status}`);
    }

    const { data } = await response.json();
    showValidationInPanel(data, selectedText);
  } catch (error) {
    panel.innerHTML = `
      <div style="background: linear-gradient(135deg, #6841E6 0%, #582FD2 100%); padding: 16px; border-radius: 8px 8px 0 0; color: white;">
        <div style="display: flex; justify-content: space-between; align-items: center;">
          <div style="font-weight: 600; font-size: 14px;">ACKO Validation</div>
          <button onclick="this.closest('#acko-validation-panel').remove()" style="background: rgba(255,255,255,0.2); border: none; color: white; width: 28px; height: 28px; border-radius: 50%; cursor: pointer; font-size: 18px;">×</button>
        </div>
      </div>
      <div style="padding: 20px;">
        <div style="background: #FFF1F2; padding: 16px; border-radius: 6px; border-left: 3px solid #BE123C;">
          <div style="font-weight: 600; color: #BE123C; margin-bottom: 4px;">Error</div>
          <div style="font-size: 13px; color: #6B7280;">${error.message}</div>
          <div style="font-size: 12px; color: #6B7280; margin-top: 8px;">Make sure the API server is running at ${settings.apiEndpoint}</div>
        </div>
      </div>
    `;
  }
}

// Scan entire page
async function scanPage() {
  const elements = [
    ...document.querySelectorAll('h1, h2, h3, p, button, a, label, [role="button"]'),
  ];

  const textElements = elements
    .map((el) => ({
      element: el,
      text: el.textContent.trim(),
    }))
    .filter((item) => item.text.length > 10 && item.text.length < 500);

  const validationPromises = textElements.slice(0, 10).map(async (item) => {
    try {
      const response = await fetch(`${settings.apiEndpoint}/acko-validator/validate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          content: item.text,
          contentType: 'ui-copy',
        }),
      });

      const { data } = await response.json();
      return {
        text: item.text,
        score: data.score,
        violations: data.violations,
      };
    } catch (error) {
      return null;
    }
  });

  const results = (await Promise.all(validationPromises)).filter(Boolean);
  return results;
}

// Listen for messages from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getSelection') {
    const selectedText = window.getSelection().toString().trim();
    sendResponse({ text: selectedText });
  }

  if (request.action === 'validate') {
    validateSelection();
  }

  if (request.action === 'scanPage') {
    scanPage().then((content) => {
      sendResponse({ content });
    });
    return true; // Keep channel open for async response
  }
});

// Alt+Click to validate
document.addEventListener('mouseup', (e) => {
  if (settings.altClick && e.altKey) {
    const selectedText = window.getSelection().toString().trim();
    if (selectedText && selectedText.length > 3) {
      setTimeout(() => validateSelection(), 100);
    }
  }
});

// Listen for keyboard shortcut
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'validateShortcut') {
    validateSelection();
  }
});

console.log('ACKO Content Validator extension loaded');
