// Background service worker for ACKO Content Validator

// Install event
chrome.runtime.onInstalled.addListener(() => {
  console.log('ACKO Content Validator installed');

  // Create context menu
  chrome.contextMenus.create({
    id: 'acko-validate-selection',
    title: 'Validate with ACKO',
    contexts: ['selection'],
  });

  chrome.contextMenus.create({
    id: 'acko-validate-page',
    title: 'Scan Page for ACKO Guidelines',
    contexts: ['page'],
  });

  // Set default settings
  chrome.storage.sync.get(['settings'], (result) => {
    if (!result.settings) {
      chrome.storage.sync.set({
        settings: {
          autoFix: false,
          altClick: true,
          apiEndpoint: 'http://localhost:5000',
        },
      });
    }
  });
});

// Context menu click handler
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === 'acko-validate-selection') {
    chrome.tabs.sendMessage(tab.id, { action: 'validate' });
  }

  if (info.menuItemId === 'acko-validate-page') {
    chrome.tabs.sendMessage(tab.id, { action: 'scanPage' }, (response) => {
      if (response && response.content) {
        // Open popup with results
        chrome.action.openPopup();
      }
    });
  }
});

// Keyboard shortcut handler
chrome.commands.onCommand.addListener((command) => {
  if (command === 'validate-selection') {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        chrome.tabs.sendMessage(tabs[0].id, { action: 'validateShortcut' });
      }
    });
  }
});

// Listen for messages from content script or popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'openOptions') {
    chrome.runtime.openOptionsPage();
  }

  if (request.action === 'getSettings') {
    chrome.storage.sync.get(['settings'], (result) => {
      sendResponse({ settings: result.settings });
    });
    return true; // Keep channel open for async response
  }
});

// Badge management
function updateBadge(tabId, violations) {
  if (violations > 0) {
    chrome.action.setBadgeText({
      text: violations.toString(),
      tabId,
    });
    chrome.action.setBadgeBackgroundColor({
      color: '#BE123C',
      tabId,
    });
  } else {
    chrome.action.setBadgeText({
      text: '',
      tabId,
    });
  }
}

// Listen for tab updates
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete') {
    // Reset badge when page loads
    chrome.action.setBadgeText({
      text: '',
      tabId,
    });
  }
});

console.log('ACKO Content Validator background service worker loaded');
